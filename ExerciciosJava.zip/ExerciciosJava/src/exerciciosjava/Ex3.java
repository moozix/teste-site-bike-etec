package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex3 {
public static void main(String[] args) {

 int num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o 1º Número: "));
 int num2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o 2º Número: "));
 for (int i = num1; i <= num2; i++) {
      if ((i % 6) ==0) {
          System.out.println("O número " + i + " é Divisivel por 6 !!");
          }else {
          System.out.println("Erro !!");
      }
 
}
}
}