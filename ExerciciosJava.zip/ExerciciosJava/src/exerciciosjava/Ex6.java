package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex6 {
    public static void main(String[] args) {
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite sua Idade: "));
        int ano = Integer.parseInt(JOptionPane.showInputDialog("Digite o Ano Atual: "));
        
        int resultado = ano - idade;
        
        System.out.println("Você Nasceu em "+resultado+" !");
        
    }
}
