package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex5 {
    
    public static void main(String[] args) {
        String nome = JOptionPane.showInputDialog("Digite seu Nome:");
        float n1,n2,n3,n4,n5,media;
        n1 = Float.parseFloat(JOptionPane.showInputDialog("Digite a 1ª Nota:"));
        n2 = Float.parseFloat(JOptionPane.showInputDialog("Digite a 2ª Nota:"));
        n3 = Float.parseFloat(JOptionPane.showInputDialog("Digite a 3ª Nota:"));
        n4 = Float.parseFloat(JOptionPane.showInputDialog("Digite a 4ª Nota:"));
        n5 = Float.parseFloat(JOptionPane.showInputDialog("Digite a 5ª Nota:"));
        
        media = (n1+n2+n3+n4+n5)/4;
        
        if (media > 7) {
            JOptionPane.showMessageDialog(null,"Olá "+nome+ "\n Sua Média é " +media+ "\n Parabens Você está Aprovado(a) !!");
             }
        else if (media >=5){
            JOptionPane.showMessageDialog(null,"Olá "+nome+ "\n Sua Média é " +media+ "\n Você está de Recuperação !!");
        }else{
            JOptionPane.showMessageDialog(null,"Olá "+nome+ "\n Sua Média é " +media+ "\n Infelizmente você está Reprovado !!");
        }
        
    }
}
