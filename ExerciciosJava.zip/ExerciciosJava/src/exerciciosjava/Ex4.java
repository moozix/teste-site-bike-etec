package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex4 {
    public static void main(String[] args) {
     int mes = Integer.parseInt(JOptionPane.showInputDialog("Digite o Número do Mês: "));
            switch(mes){
            case 1:
                JOptionPane.showMessageDialog(null, "O 1 Mês do Ano é Janeiro !!");
                break;
            case 2:
                JOptionPane.showMessageDialog(null, "O 2 Mês do Ano é Fevereiro !!");
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "O 3 Mês do Ano é Março !!");
                break;
            case 4:
                JOptionPane.showMessageDialog(null, "O 4 Mês do Ano é Abril !!");
                break;
            case 5:
                JOptionPane.showMessageDialog(null, "O 5 Mês do Ano é Maio !!");
                break;
            case 6:
                JOptionPane.showMessageDialog(null, "O 6 Mês do Ano é Junho !!");
                break;
            case 7:
                JOptionPane.showMessageDialog(null, "O 7 Mês do Ano é Julho !!");
                break;
            case 8:
                JOptionPane.showMessageDialog(null, "O 8 Mês do Ano é Agosto !!");
                break;
            case 9:
                JOptionPane.showMessageDialog(null, "O 9 Mês do Ano é Setembro !!");
                break;
            case 10:
                JOptionPane.showMessageDialog(null, "O 10 Mês do Ano é Outubro !!");
                break;
            case 11:
                JOptionPane.showMessageDialog(null, "O 11 Mês do Ano é Novembro !!");
                break;
            case 12:
                JOptionPane.showMessageDialog(null, "O 12 Mês do Ano é Dezembro !!");
                break;
                
            default:
                JOptionPane.showMessageDialog(null, "Este não é um mês válido !!");
            }
    }
}
