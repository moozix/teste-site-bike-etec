package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex11 {
    public static void main(String[] args) {
        float peso = Float.parseFloat(JOptionPane.showInputDialog("Digite seu Peso: "));
        float alt = Float.parseFloat(JOptionPane.showInputDialog("Digite sua Altura: "));
        
        float resul = peso / (alt *alt);
        
        if (resul < 16.9){
            System.out.println("Muito Abaixo do Peso !");
    }else if(resul >= 17 && resul <= 18.9){
            System.out.println("Abaixo do Peso !");
    }else if(resul >= 19 && resul <= 26.9){
            System.out.println("Normal !");
    }else if(resul >= 27 && resul <= 31.9){
            System.out.println("Acima do Peso !");
    }else {
            System.out.println("Obesidade !");
    }
    }
}
