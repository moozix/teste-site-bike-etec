package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex2 {

  
    public static void main(String[] args) {
    int num = Integer.parseInt(JOptionPane.showInputDialog("Digite o Número entre 100 e 200: ")); 
   for (int i = 100; i <= 200; i++) {
            if (((i % 2) ==0) && ((i % 3)  ==0)) {
                System.out.println("O número " + i + " é Divisivel por 2 e 3");
            } else {
                if ((i % 2) == 0) {
                    System.out.println("O número " + i + " é Divisivel por 2");
                } else {
                    if ((i % 3) == 0) {
                        System.out.println("O número " + i + " é Divisivel por 3");
                    }
                }
            }
    }
    
    }
    
}
