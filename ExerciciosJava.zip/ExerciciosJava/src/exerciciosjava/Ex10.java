package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex10 {
    public static void main(String[] args) {
        float sal = Float.parseFloat(JOptionPane.showInputDialog("Digite seu Salario Atual: "));
        float desc = Float.parseFloat(JOptionPane.showInputDialog("Digite a Porcentagem de Desconto: "));
        
        float resul = sal * (desc/100);
        float resulf = sal - resul;
        
        System.out.println("Seu Salario Será de: "+resulf+" !");
        
    }
}
