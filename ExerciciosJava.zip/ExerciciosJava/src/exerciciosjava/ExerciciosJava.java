package exerciciosjava;

import javax.swing.JOptionPane;

public class ExerciciosJava {

    public static void main(String[] args) {
        
        int mes = Integer.parseInt(JOptionPane.showInputDialog("Digite o Mês: "));
       if(mes >= 1 && mes <=6){
            JOptionPane.showMessageDialog(null,"O Mês "+mes+" faz Parte do 1º Semestre");   
            
    }else if(mes >= 7 && mes <=12){
            JOptionPane.showMessageDialog(null,"O Mês "+mes+" faz Parte do 2º Semestre");
        
    }else {
        JOptionPane.showMessageDialog(null,"Digite um Mês de 1 a 12 sendo 1 Janeiro e 12 Dezembro");
        }
        switch(mes){
            case 1:
                JOptionPane.showMessageDialog(null, "Janeiro !!");
                break;
            case 2:
                JOptionPane.showMessageDialog(null, "Fevereiro !!");
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "Março !!");
                break;
            case 4:
                JOptionPane.showMessageDialog(null, "Abril !!");
                break;
            case 5:
                JOptionPane.showMessageDialog(null, "Maio !!");
                break;
            case 6:
                JOptionPane.showMessageDialog(null, "Junho !!");
                break;
            case 7:
                JOptionPane.showMessageDialog(null, "Julho !!");
                break;
            case 8:
                JOptionPane.showMessageDialog(null, "Agosto !!");
                break;
            case 9:
                JOptionPane.showMessageDialog(null, "Setembro !!");
                break;
            case 10:
                JOptionPane.showMessageDialog(null, "Outubro !!");
                break;
            case 11:
                JOptionPane.showMessageDialog(null, "Novembro !!");
                break;
            case 12:
                JOptionPane.showMessageDialog(null, "Dezembro !!");
                break;
                
            default:
                JOptionPane.showMessageDialog(null, "Este não é um dia válido !!");
        
    }
    
    }
}
