package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex9 {
    public static void main(String[] args) {
        
        float  temp = Float.parseFloat(JOptionPane.showInputDialog("Digite a Temperatura em Graus: "));
        
        float resultado = (temp*9/5)+32;
        
        System.out.println("O Valor em Fahrenheit é: "+resultado+" !");
    }
}
