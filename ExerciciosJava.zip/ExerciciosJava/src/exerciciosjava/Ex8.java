package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex8 {
    public static void main(String[] args) {
        int num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o 1º Número: "));
        int num2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o 2º Número: "));
        int num3 = Integer.parseInt(JOptionPane.showInputDialog("Digite o 3º Número: "));
        
        if (num1 > num2 && num1 > num3){
            System.out.println("O Número "+num1+ " é o Maior !!");
        }else if(num2 > num1 && num2 > num3){
            System.out.println("O Número "+num2+ " é o Maior !!");
        }else if(num3 > num1 && num3 > num2){
            System.out.println("O Número "+num3+ " é o Maior !!");
      }else{
            System.out.println("Erro !!");
        }
    }
}
