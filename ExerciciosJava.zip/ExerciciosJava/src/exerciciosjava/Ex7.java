package exerciciosjava;

import javax.swing.JOptionPane;

public class Ex7 {
    public static void main(String[] args) {
        int num = Integer.parseInt(JOptionPane.showInputDialog("Digite o Número: "));
        if (num % 2 == 0){
            System.out.println("PAR !!");
        }else{
            System.out.println("ÍMPAR !!");
        }
    }
    
}
